CREATE VIEW 员工工资 AS
  (SELECT
     `salary`.`员工`.`姓名`                                                           AS `员工姓名`,
     `salary`.`部门`.`部门名称`                                                         AS `所属部门`,
     `salary`.`职称`.`职称名`                                                          AS `职位`,
     `salary`.`工资类别`.`月基本工资`                                                      AS `月基本工资`,
     (`salary`.`员工`.`总加班天数` * `salary`.`工资类别`.`日加班费`)                             AS `加班费`,
     (`salary`.`员工`.`总缺勤天数` * `salary`.`工资类别`.`日缺勤费`)                             AS `应扣工资`,
     ((((`salary`.`工资类别`.`月基本工资` * 12) + (`salary`.`员工`.`总加班天数` * `salary`.`工资类别`.`日加班费`)) -
       (`salary`.`员工`.`总缺勤天数` * `salary`.`工资类别`.`日缺勤费`)) + `salary`.`工资类别`.`年终奖`) AS `年总工资`
   FROM (((`salary`.`员工`
     JOIN `salary`.`部门` ON ((`salary`.`员工`.`部门编号` = `salary`.`部门`.`部门编号`))) JOIN `salary`.`职称`
       ON ((`salary`.`员工`.`职称编号` = `salary`.`职称`.`职称编号`))) JOIN `salary`.`工资类别`
       ON (((`salary`.`员工`.`职称编号` = `salary`.`工资类别`.`职称编号`) AND (`salary`.`员工`.`部门编号` = `salary`.`工资类别`.`部门编号`)))));

